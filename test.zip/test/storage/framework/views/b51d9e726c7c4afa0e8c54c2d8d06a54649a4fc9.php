<!DOCTYPE html>
<html>
<head>
<title>Test Form</title>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
<div class="container mt-4">

<div class="card">
<div class="card-header text-center font-weight-bold">
<h2>Laravel 8 Form Validation Tutorial</h2>
</div>
<div class="card-body">
<form name="employee" id="employee" method="post" action="<?php echo e(url('store-form')); ?>">
<?php echo csrf_field(); ?>
<div class="form-group">
<label for="exampleInputEmail1">Name</label>
<input type="text" id="name" name="name" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">

</div>        
<div class="form-group">
<label for="exampleInputEmail1">Email</label>
<input type="email" id="email" name="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">

</div>        
<div class="form-group">
<label for="exampleInputEmail1">Age</label>
<input type="number" id="age" name="age" class="<?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">

</div>        
<button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</div>
</div>  
</body>
</html>
<?php /**PATH F:\xampp\htdocs\test\resources\views/form.blade.php ENDPATH**/ ?>